const jwt = require("jsonwebtoken");

const Node = require("../models/Node");

const setNodes = async(req, res) => {
  // console.log(req.decoded)
  const data = req.body.credential;
  const existNodes = await Node.find({})
  // console.log(Date.now())
  // console.log(data, "first")
  if(existNodes.length > 0) {
    await Node.updateMany ({}, {nodes: data})
  } else {
    const newNodes = new Node({
      nodes: data          
    })
    // console.log(data)
    newNodes.save()
  }
  res.status(200).json({ message: "Successfully saved" })
}

const getNodes = async(req, res) => {
  const existNodes = await Node.find({})
  // console.log(existNodes)
  res.status(200).json({ nodes: existNodes[0].nodes })
}
module.exports = {
  getNodes,
  setNodes
};