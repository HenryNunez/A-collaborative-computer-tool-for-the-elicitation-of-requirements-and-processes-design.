const jwt = require("jsonwebtoken");

const { OAuth2Client } = require("google-auth-library");
const User = require("../models/User");
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const client = new OAuth2Client(GOOGLE_CLIENT_ID);

const verifyGoogleToken = async (token) => {
  try {
    const ticket = await client.verifyIdToken({
      idToken: token,
      audience: GOOGLE_CLIENT_ID,
    });
    return { payload: ticket.getPayload() };
  } catch (error) {
    return { error: "Invalid user detected. Please try again" };
  }
}

const signUp = async(req, res) => {
  try {

    if (req.body.credential) {
      const verificationResponse = await verifyGoogleToken(req.body.credential);

      if (verificationResponse.error) {
        return res.status(400).json({
          message: verificationResponse.error,
        });
      }
      

      const profile = verificationResponse?.payload;

      const user = await User.findOne({email: profile?.email});
      if(user) {
        return res.status(400).json({
          code: 400,
          message: "Sorry! Email address already exists."
        })
      } 
      const newUser = new User({
        firstName: profile?.given_name,
        lastName: profile?.family_name,
        picture: profile?.picture,
        email: profile?.email,          
      })

      newUser.save()
      const token = await jwt.sign({           
        firstName: profile?.given_name,
        lastName: profile?.family_name,
        picture: profile?.picture,
        email: profile?.email
      }, process.env.JWT_SECRET, { expiresIn: 86400 });
      const bearerToken = `Bearer ${token}`;

      res.status(201).json({
        message: "Signup was successful",
        user: bearerToken,
      });
    }
  } catch (error) {
    res.status(500).json({
      message: "An error occured. Registration failed.",
    });
  }
}

const login = async(req, res) => {
  try {

    if (req.body.credential) {
      const verificationResponse = await verifyGoogleToken(req.body.credential);
      if (verificationResponse.error) {
        return res.status(400).json({
          message: verificationResponse.error,
        });
      }

      const profile = verificationResponse?.payload;

      const existsInDB = await User.findOne({email: profile.email});

      if (!existsInDB) {
        return res.status(400).json({
          message: "You are not registered. Please sign up",
        });
      }
      const token = await jwt.sign({           
        firstName: profile?.given_name,
        lastName: profile?.family_name,
        picture: profile?.picture,
        email: profile?.email
      }, process.env.JWT_SECRET, { expiresIn: 86400 });
      const bearerToken = `Bearer ${token}`;

      res.status(201).json({
        message: "Login was successful",
        user: bearerToken,
      });
    }
  } catch (error) {
    res.status(500).json({
      message: error?.message || error,
    });
  }
}

const getUsers = async(req, res) => {
  // console.log(req.decoded)
  await User.findOneAndUpdate({email: req.decoded.email}, {lastLogin: Date.now()})
  // console.log(Date.now())
  const usersData = await User.find({lastLogin: {$gt: Date.now() - 30000}})
  const users = [];
  for (let i = 0; i < usersData.length; i++) {
    const user = {};
    user.firstName = usersData[i].firstName;
    user.picture = usersData[i].picture;
    users.push(user)
  }
  // console.log(users)
  res.status(200).json({ users: users })
}
module.exports = {
  signUp,
  login,
  getUsers,
};