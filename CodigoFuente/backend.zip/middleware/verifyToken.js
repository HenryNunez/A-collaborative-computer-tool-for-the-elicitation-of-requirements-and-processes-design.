const jwt = require('jsonwebtoken');
const jwtSecret = process.env.JWT_SECRET;

function verifyToken(req, res, next) {
  const bearerToken = req.body.token || req.query.token || req.headers['x-access-token'] || req.headers['Authorization'];
  // console.log(bearerToken);
  const token = bearerToken.split(' ')[1];
  // console.log(token);

  if (token) {
    jwt.verify(token, jwtSecret, function (err, decoded) {
      if (err) {
         return res.status(403).send({
          success: false,
          message: 'Failed to authenticate.'
        });
      } else {
        req.decoded = decoded
        next()
      }
    })
  } else {
    return res.status(403).send({
      success: false,
      message: 'No token provided.'
    });
  }
}
module.exports.verifyToken = verifyToken;