const mongoose = require('mongoose')

const NodeSchema = mongoose.Schema({
  nodes: {
    type: String,
    required: false
  },
  createdAt: {
    type: Date,
    default: Date.now()
  },
  lastUpdatedAt: {
    type: Date,
    default: Date.now(),
    required: false
  },
})

module.exports = Node = mongoose.model('nodes', NodeSchema)