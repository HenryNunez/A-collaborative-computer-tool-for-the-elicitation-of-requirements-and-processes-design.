const mongoose = require('mongoose')

const UserSchema = mongoose.Schema({
  firstName: {
    type: String,
    required: false
  },
  lastName: {
    type: String,
    required: false
  },
  email: {
    type: String,
    required: true
  },
  picture: {
    type: String,
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now()
  },
  lastUpdatedAt: {
    type: Date,
    default: Date.now(),
    required: false
  },
  lastLogin: {
    type: Date,
    required: false
  }
})

module.exports = User = mongoose.model('users', UserSchema)