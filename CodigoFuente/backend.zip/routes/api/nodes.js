const router = require("express").Router();
const { getNodes, setNodes } = require("../../controllers/node");
const verifyToken = require('../../middleware/verifyToken')

router.post("/setnodes", verifyToken.verifyToken, setNodes);
router.get("/getnodes", verifyToken.verifyToken, getNodes);

module.exports = router;