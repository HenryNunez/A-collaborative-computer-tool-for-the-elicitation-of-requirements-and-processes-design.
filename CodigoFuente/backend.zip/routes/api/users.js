const router = require("express").Router();
const passport = require('passport')
const { signUp, login, getUsers } = require("../../controllers/user");
const verifyToken = require('../../middleware/verifyToken')

router.post("/signup", signUp);
router.post("/login", login);
router.get("/getusers", verifyToken.verifyToken, getUsers);

module.exports = router;