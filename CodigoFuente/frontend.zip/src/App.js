import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import React, { useState, useEffect } from "react";
import { toPng } from "html-to-image";
import jwt_decode from "jwt-decode";
import 'bootstrap/dist/css/bootstrap.min.css';

import Navbar from "./Layouts/Navbar";
import Home from "./pages/Home";
import Login from "./pages/Login";
import SignUp from "./pages/SignUp";
import { NewDesign, PrintCheck, ModeChanage } from "./components/Modal";

import { MyContext } from "./globalContext";
import setAuthToken from "./setAuthToken";


function downloadImage(dataUrl) {
  const a = document.createElement("a");

  a.setAttribute("download", "ISEA.png");
  a.setAttribute("href", dataUrl);
  a.click();
}

function App() {

  const [user, setUser] = useState({});
  const [newDesignShow, setNewDesignShow] = useState(false);
  const [printCheck, setPrintCheck] = useState(false);
  const [mode, setMode] = useState(false);
  const [changeMode, setChangeMode] = useState(false);


  const [edgeColor, setedgeColor] = useState("");
  const [refresh, setRefresh] = useState(false);

  useEffect(() => {
    const userInfo = localStorage.getItem("token");
    if (userInfo) {
      setAuthToken(userInfo);
      const userDecoded = jwt_decode(userInfo);
      setUser(userDecoded);
      // console.log(userDecoded)
      const currentTime = Date.now() / 1000
      if (userDecoded.exp < currentTime) {
        // Logout
        // store.dispatch(logoutUser());
        // // User
        // store.dispatch(setCurrentUser({}));
        setUser({});
        localStorage.removeItem('token')
        window.location.href = "/login"
      }
    }
  }, []);

  const Print = () => {
    toPng(document.querySelector(".react-flow"), {
      filter: (node) => {
        if (
          node?.classList?.contains("react-flow__minimap") ||
          node?.classList?.contains("react-flow__controls")
        ) {
          return false;
        }
        return true;
      },
    }).then(downloadImage);
  };

  const Refresh = (item) => {
    if (item === "Nuevo Diseño") {
      setNewDesignShow(true);
    } else if (item === "Imprimir") {
      setPrintCheck(true)
    } else if (item === "Cerrar Sesión") {
      localStorage.setItem("token", "");
      window.location.reload();
    } else if (item === "Diseño ISEA" && mode === true) {
      setChangeMode(true);

    } else if (item === "Diseño General" && mode === false) {
      setChangeMode(true);
    }
  };
  return (
    <MyContext.Provider
      value={[edgeColor, setedgeColor]}
    >
      {user?.email ? <Navbar onClickBtn={Refresh} /> : ""}
      <BrowserRouter>
        <Routes>
          <Route
            path="/"
            element={
              user?.email ? <Navigate to="/home" /> : <Navigate to="/login" />
            }
          />
          <Route
            path="/signup"
            element={user?.email ? <Navigate to="/home" /> : <SignUp />}
          />
          <Route
            path="/login"
            element={user?.email ? <Navigate to="/home" /> : <Login />}
          />
          <Route
            path="/home"
            element={user?.email ? <Home mode={mode} onClickBtn={Refresh} newDesign={refresh} userInfo={user} /> : <Navigate to="/login" />}
          />
        </Routes>
      </BrowserRouter>
      <NewDesign show={newDesignShow} onHide={() => setNewDesignShow(false)} onAllow={() => { setRefresh(!refresh); setNewDesignShow(false) }} />
      <PrintCheck show={printCheck} onHide={() => setPrintCheck(false)} onAllow={() => { Print(); setPrintCheck(false) }} />
      <ModeChanage show={changeMode} onHide={() => setChangeMode(false)} onChangeMode={() => { setChangeMode(false); setMode(!mode); setNewDesignShow(true); }} />
    </MyContext.Provider >
  );
}

export default App;


