import React from "react";
import styled from "styled-components";

import Button from "../components/Button";

const navbarbtns = [
  {
    text: "Imprimir",
  },
];

function Footer(props) {
  return (
    <Wrapper>
      {navbarbtns.map((btn, i) => (
        <Button key={`btn-${i}`} text={btn.text} func={props.onClick} />
      ))}
    </Wrapper>
  );
}

export default Footer;

const Wrapper = styled.div`
  width: 99%;
  height: auto;
  margin: 5px;
  background: transparent;
  overflow: auto;
  @media screen and (max-width: 500px) {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
  }
`;
