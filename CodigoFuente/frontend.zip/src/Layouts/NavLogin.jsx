import * as React from "react";

export default function NavLogin() {
  return (
    <div style={{ display: "flex", justifyContent: "center", alignItems: "center",  fontSize: "30px", fontWeight: "bold", height: "11vh", paddingTop: "30px" }}>
      <img alt="avata" src={"assets/images/logo1.png"} style={{marginTop: "75px", marginRight: "15px"}} width="150px" height="180px" />
      <h1> isEASY Modeler </h1>
    </div>
  );
}
