import React, { useState, useEffect } from "react";
import styled from "styled-components";

import api from "../api";
import { url } from "../constant";

import Button from "../components/Button";
import Avatas from "../components/Avatars";
import LogoImg from "../components/LogoImg";

const navbarbtns = [
  {
    text: "Cerrar Sesión",
  },
  {
    text: "Nuevo Diseño",
  },
  {
    text: "Diseño ISEA",
  },
  {
    text: "Diseño General",
  },
];

const logoimgs = [
  {
    img: "assets/images/logo.png",
  },
];

function Navbar(props) {
  const [activeUsers, setActiveUsers] = useState([]);
  useEffect(() => {
    const interval = setInterval(() => {
      api(`${url}/api/users/getusers`, "", "GET").then((res) => {
        if (
          JSON.stringify(activeUsers) !== JSON.stringify(res) &&
          Array.isArray(res)
        ) {
          setActiveUsers((prev) => res);
        }
      });
    }, 10000);
    return () => clearInterval(interval);
  }, []);
  return (
    <Wrapper>
      {logoimgs.map((logo, i) => (
        <LogoImg key={`logo-${i}`} logo={logo.img} />
      ))}
      {navbarbtns.map((btn, i) => (
        <Button key={`btn-${i}`} text={btn.text} func={props.onClickBtn} />
      ))}
      {activeUsers.map((avata, i) => (
        <Avatas key={`avata-${i}`} avata={avata} />
      ))}
    </Wrapper>
  );
}

export default Navbar;

const Wrapper = styled.div`
  width: 99%;
  height: auto;
  margin: 5px;
  background: transparent;
  overflow: auto;
  @media screen and (max-width: 500px) {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
  }
`;
