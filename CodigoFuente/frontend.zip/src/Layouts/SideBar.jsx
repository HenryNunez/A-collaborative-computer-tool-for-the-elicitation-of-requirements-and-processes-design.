import React, { useState } from "react";
import styled from "styled-components";
import SideBarItems from "../components/SideBarItem";

const fullTools = [
  {
    type: "Post",
    img: "assets/images/tools/post.jpg",
    colorSelectable: true,
    position: "160px",
    num: 0,
    width: "350px",
    height: "300px",
    color: "Gold",
    zIndex: "1",
  },
  {
    type: "Clock",
    img: "assets/images/tools/clock.jpg",
    colorSelectable: false,
    width: "133px",
    height: "35px",
    zIndex: "2",
  },
  {
    type: "Docs",
    img: "assets/images/tools/docs.jpg",
    colorSelectable: false,
    width: "133px",
    height: "35px",
    zIndex: "2",
  },
  {
    type: "Line",
    img: "assets/images/tools/line.jpg",
    colorSelectable: true,
    position: "340px",
    num: 1,
    zIndex: "2",
    color: "DodgerBlue",
  },
  {
    type: "Loop",
    img: "assets/images/tools/loop.jpg",
    colorSelectable: false,
    width: "133px",
    height: "35px",
    zIndex: "2",
  },
  {
    type: "Stop",
    img: "assets/images/tools/stop.jpg",
    colorSelectable: false,
    width: "133px",
    height: "35px",
    zIndex: "2",
  },
  {
    type: "Circle",
    img: "assets/images/tools/circle.png",
    colorSelectable: true,
    position: "500px",
    num: 2,
    width: "60px",
    height: "30px",
    radius: "50%",
    color: "Gold",
    zIndex: "2",
  },
];

const generalTools = [
  {
    type: "Post",
    img: "assets/images/tools/post.jpg",
    colorSelectable: true,
    position: "160px",
    num: 0,
    width: "350px",
    height: "300px",
    color: "Gold",
    zIndex: "1",
  },
  {
    type: "Line",
    img: "assets/images/tools/line.jpg",
    colorSelectable: true,
    position: "340px",
    num: 1,
    zIndex: "2",
    color: "DodgerBlue",
  },
];

function SideBar(props) {
  const [show, setShow] = useState([false, false, false]);
  const processShow = (item) => {
    let initialState = [false, false, false];
    if (item === undefined) {
      setShow(initialState);
      initialState[item] = true;
      setShow(initialState);
    } else {
      initialState[item] = !show[item];
      setShow(initialState);
    }
  };
  return (
    <Wrapper isHeight={props.mode}>
      <Text>
        Dar CLICK
        <br /> en cada elemento y<br /> ARASTRAR
      </Text>
      {props.mode
        ? generalTools.map((tool, i) => (
            <>
              <SideBarItems
                key={i}
                nodeInfo={tool}
                show={show}
                func={processShow}
              />
            </>
          ))
        : fullTools.map((tool, i) => (
            <>
              <SideBarItems
                key={i}
                nodeInfo={tool}
                show={show}
                func={processShow}
              />
            </>
          ))}
      <Text>
        Parra BORRAR un elemento, hacer CLICK en el elemento y PRESIONE
        Backspace
      </Text>
    </Wrapper>
  );
}

export default SideBar;

const Wrapper = styled.div`
  width: 120px;
  height: ${(props) => (props.isHeight ? "50vh" : "80vh")};
  margin: 5px 5px 5px 33px;
  padding: 1px;
  background: #4774d5;
  border-radius: 5px;
  display: flex;
  flex-direction: column;
  position: 'fixed'
  align-items: center;
  justify-content: center;
`;

const Text = styled.h6`
  text-align: center;
  margin: 1px;
  font-size: 12px;
  font-weight: bold;
`;
