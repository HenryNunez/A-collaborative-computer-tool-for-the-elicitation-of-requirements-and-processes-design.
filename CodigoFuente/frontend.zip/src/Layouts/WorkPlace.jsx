import React, { useState, useCallback, useRef, useEffect } from "react";
import styled from "styled-components";
import ReactFlow, {
  Background,
  Controls,
  useNodesState,
  useEdgesState,
  addEdge,
  MarkerType,
} from "reactflow";
import "reactflow/dist/style.css";

import ColorEdge from "../customEgdes/ColorEdge";

import PostNode from "../customNodes/PostNode";
import ClockNode from "../customNodes/ClockNode";
import DocsNode from "../customNodes/DocsNode";
import LoopNode from "../customNodes/LoopNode";
import StopNode from "../customNodes/StopNode";
import CircleNode from "../customNodes/CircleNode";

import { MyContext } from "../globalContext";
import { url } from "../constant";
import api from "../api";

let id = 0;
const getId = () => {
  return "id:" + id++;
};

const nodeTypes = {
  Post: PostNode,
  Clock: ClockNode,
  Docs: DocsNode,
  Loop: LoopNode,
  Stop: StopNode,
  Circle: CircleNode,
};

const edgeTypes = {
  ColorEdge: ColorEdge,
};

function WorkPlace(props) {
  const reactFlowWrapper = useRef(null);
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [reactFlowInstance, setReactFlowInstance] = useState(null);
  const [condition, setCondition] = useState(0);

  // Send nodes data to server.
  useEffect(() => {
    // console.log("Nodes ", JSON.stringify(nodes));
    if (condition > 1) {
      api(
        `${url}/api/nodes/setnodes`,
        JSON.stringify({ nodes, edges }),
        "POST"
      );
    } else {
      setCondition((prev) => prev + 1);
    }
  }, [nodes, edges]);

  useEffect(() => {
    const interval = setInterval(() => {
      api(`${url}/api/nodes/getnodes`, "", "GET").then((res) => {
        // console.log(JSON.parse(res), "nodes");
        id = JSON.parse(res).nodes.length;
        setNodes((nds) => JSON.parse(res).nodes);
        setEdges((nds) => JSON.parse(res).edges);
      });
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  let refresh = props.newDesign;
  useEffect(() => {
    setNodes([]);
    setEdges([]);
    id = 0;
  }, [refresh]);

  const onDragOver = useCallback((event) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = "move";
  }, []);

  const [edgeColor] = React.useContext(MyContext);

  const onConnect = (params) =>
    setEdges((eds) =>
      addEdge(
        {
          ...params,
          type: "ColorEdge",
          data: { color: edgeColor },
          animated: true,
          markerEnd: {
            type: MarkerType.Arrow,
            color: edgeColor,
            strokeWidth: "1.5",
          },
        },
        eds
      )
    );

  const onDrop = useCallback((event, node) => {
    event.preventDefault();
    const reactFlowBounds = reactFlowWrapper.current.getBoundingClientRect();
    const nodeObjStr = event.dataTransfer.getData("application/reactflow");
    let nodeObj = JSON.parse(nodeObjStr);

    let nodeId = getId();
    const type = nodeObj.type;

    if (typeof type === "undefined" || !type) {
      return;
    }

    const position = reactFlowInstance.project({
      x: event.clientX - reactFlowBounds.left,
      y: event.clientY - reactFlowBounds.top,
    });
    if (type === "Post") {
      const newNode = {
        id: nodeId,
        type,
        position,
        data: {
          img: nodeObj.img,
          label: type,
          label1: "",
          username: props.userInfo.firstName + props.userInfo.lastName,
          userAvatar: props.userInfo.picture,
        },
        style: {
          background: `${nodeObj.color}`,
          zIndex: `${nodeObj.zIndex}`,
          width: `${nodeObj.width}`,
          height: `${nodeObj.height}`,
          borderRadius: `${nodeObj.radius}`,
        },
        selectable: true,
        zIndex: nodeObj.zIndex,
      };
      setNodes((nds) => nds.concat(newNode));
    } else {
      const newNode = {
        id: nodeId,
        type,
        position,
        data: { img: nodeObj.img, label: type },
        style: {
          background: `${nodeObj.color}`,
          zIndex: `${nodeObj.zIndex}`,
          width: `${nodeObj.width}`,
          height: `${nodeObj.height}`,
          borderRadius: `${nodeObj.radius}`,
        },
        parentNode: undefined,
        extent: "parent",
        selectable: true,
        zIndex: nodeObj.zIndex,
      };
      setNodes((nds) => nds.concat(newNode));
    }
  });

  const handleDragEnd = useCallback(
    (event, node) => {
      let groupNode = node;
      if (node.type === "Post") return;
      nodes.forEach((nds) => {
        if (nds.type === "Post") {
          if (
            nds.position.x <= node.position.x &&
            nds.position.x + parseInt(nds.style?.width?.toString() || "0") >=
              node.position.x &&
            nds.position.y <= node.position.y &&
            nds.position.y + parseInt(nds.style?.height?.toString() || "0") >=
              node.position.y
          ) {
            groupNode = nds;
          }
        }
      });
      if (groupNode.id !== node.id) {
        setNodes((prevNodes) => {
          return prevNodes.map((nds) => {
            if (nds.id === node.id) {
              nds.parentNode = groupNode?.id;
              nds.position = {
                x: node.positionAbsolute.x - groupNode.position.x,
                y: node.positionAbsolute.y - groupNode.position.y,
              };
            }
            return nds;
          });
        });
      } else {
        setNodes((prevNodes) => {
          return prevNodes.map((nds) => {
            if (nds.id === node.id) {
              nds.parentNode = undefined;
              nds.position = node.positionAbsolute;
            }
            return nds;
          });
        });
      }
    },
    [nodes, setNodes]
  );

  return (
    <Wrapper ref={reactFlowWrapper}>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        nodeTypes={nodeTypes}
        edgeTypes={edgeTypes}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onDrop={onDrop}
        onDragOver={onDragOver}
        onNodeDragStop={handleDragEnd}
        minZoom={0.2}
        maxZoom={8}
        onInit={setReactFlowInstance}
      >
        <Controls position="bottom-right" />
        <Background />
      </ReactFlow>
    </Wrapper>
  );
}

export default WorkPlace;

const Wrapper = styled.div`
  width: 99%;
  padding: 5px;
  display: flex;
  height: 74vh;
  background: transparent;
`;
