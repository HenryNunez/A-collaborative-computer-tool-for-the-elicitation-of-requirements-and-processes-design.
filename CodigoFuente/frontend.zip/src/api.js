import axios from "axios";
const api = async (url, credential, method) => {
  try {
    if (method === "POST") {
      const data = await axios.post(url, { credential: credential });
      // console.log(data);
      if (data?.data?.user) {
        localStorage.setItem("token", data?.data?.user);
        window.location.reload();
        return data?.data?.message;
      }
    } else {
      const data = await axios.get(url);
      if (data?.data?.users) {
        return data?.data?.users;
      }

      if(data?.data?.nodes) {
        return data?.data?.nodes;
      }
    }
  } catch (err) {
    // console.log(err?.response?.data?.message, "dd");
    return err?.response?.data?.message;
  }
};

export default api;
