import React from "react";
import styled from "styled-components";
const Avatas = (props) => {
  return (
    <Avata>
      <img alt={props.avata.firstName} src={`${props.avata.picture}`} width="100%" height="100%" style={{borderRadius: "50%"}}/>
    </Avata>
  );
};

export default Avatas;

const Avata = styled.div`
  margin: 12px 15px 12px -23px;
  float: right;
  width: 50px;
  height:38px;
  border-radius: 50%;
  background: yellow;
`;
