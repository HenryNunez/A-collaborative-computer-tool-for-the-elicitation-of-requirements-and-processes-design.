import React from "react";
import styled from "styled-components";

const Buttons = (props) => {
  return <Button onClick={()=> props.func(props.text)} >{props.text}</Button>;
};

export default Buttons;

const Button = styled.button`
  float: right;
  background: #4774D5;
  padding: 12px 0;
  margin: 11px 10px 11px 10px;
  width: 120px;
  border: none;
  border-radius: 5px;
  color: white;
  font-weight: bold;
  font-family: Segoe UI, sans-serif;
  @media screen and (max-width: 500px) {   
      float: none;
      display: block;
      width: 95%;
      margin: 5px;
  }
`;
