import React, { useState } from "react";
import styled from "styled-components";

const ColorBtn = (props) => { 
  return (
    <Color
      color={props.color}
      selected={props.selected}
      onClick={() => props.setColor(props.color)}
    />
  );
};

export default ColorBtn;

const Color = styled.div`
  width: 20px;
  height: 20px;
  margin: 8px;
  border-radius: 50%;
  border: ${(props) => (props.selected ? "1px solid black" : "none")};
  background: ${(props) => props.color};
  cursor: pointer;
`;
