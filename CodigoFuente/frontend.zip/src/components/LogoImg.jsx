import React from "react";
import styled from "styled-components";
const LogoImg = (props) => {
  return (
    <Logo>
      <img alt="logo" src={props.logo} width="60px" height="70px" />
      <Text>isEASY Modeler</Text>
    </Logo>
  );
};

export default LogoImg;

const Logo = styled.div`
  margin: 2px 5px 0px 30px;
  float: left;
  font-weight: bold;
  font-family: Segoe UI, sans-serif;
`;

const Text = styled.h1`
  margin: 9px 5px 10px 15px;
  float: right;
  font-weight: bold;
  font-family: Segoe UI, sans-serif;
`;
