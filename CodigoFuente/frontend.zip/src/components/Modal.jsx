import React from "react";
import styled from "styled-components";

function NewDesign(props) {
  if (!props.show) {
    return null;
  }
  return (
    <Modal onClick={props.onHide}>
      <ModalContent>
        <ModalHeader>
          <h4>Alerta!</h4>
        </ModalHeader>
        <ModalBody>
          <h6>Se borrará todo el diseño, estas seguro?</h6>
        </ModalBody>
        <ModalFooter>
          <Button onClick={props.onHide}>CERRAR</Button>
          <Button onClick={props.onAllow}>OK</Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
}

function PrintCheck(props) {
  if (!props.show) {
    return null;
  }
  return (
    <Modal onClick={props.onHide}>
      <ModalContent>
        <ModalHeader>
          <h4>Alerta!</h4>
        </ModalHeader>
        <ModalBody>
          <h6>Reajuste el tamaño del diseño antes de imprimir?</h6>
        </ModalBody>
        <ModalFooter>
          <Button onClick={props.onHide}>CERRAR</Button>
          <Button onClick={props.onAllow}>OK</Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
}

function ModeChanage(props) {
  if (!props.show) {
    return null;
  }
  return (
    <Modal onClick={props.onHide}>
      <ModalContent>
        <ModalHeader>
          <h4>Alerta!</h4>
        </ModalHeader>
        <ModalBody>
          <h6>Reajuste el tamaño del diseño antes de imprimir?</h6>
        </ModalBody>
        <ModalFooter>
          <Button onClick={props.onHide}>CERRAR</Button>
          <Button onClick={props.onChangeMode}>OK</Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
}


function AboutModal(props) {
  if (!props.show) {
    return null;
  }
  return (
    <Modal onClick={props.onHide}>
      <ModalContent color={props.about}>
        <ModalHeader>
          <div style={{ width: "50%", padding: "20px" }}>
            <img
              alt="avata"
              src={"assets/images/about.png"}
              width="180px"
              height="80px"
              style={{float: "right"}}
            />
          </div>
          <div style={{ width: "50%", padding: "20px" }}>
            <img
              alt="avata"
              src={"assets/images/logo1.png"}
              width="70px"
              height="80px"
              style={{float: "left"}}
            />
            <img
              alt="avata"
              src={"assets/images/logo2.png"}
              width="200px"
              height="35px"
              style={{float: "left", marginTop: "12px"}}
            />
          </div>
        </ModalHeader>
        <ModalBody>
          <h4 style={{ margin: "0px" }}>About us</h4>
          <h4 style={{ margin: "0px" }}>
            Este proyecto es una herramienta informática colaborativa para la
            elicitación de requerimientos y diseño de procesos. El proyecto fue
            creado por Henry Jonathan Núñez Samaniego estudiante de la Facultad
            de Ingeniería de Sistemas de la Escuela Politécnica Nacional del
            Ecuador bajo la dirección de Dr. Marco Santórum y Dra. Mayra
            Carrión.
          </h4>
        </ModalBody>
        <ModalFooter>
          <h4 style={{ margin: "0px" }}>Contact us</h4>
          <h4 style={{ margin: "0px" }}>Email: henrynuepn@gmail.com</h4>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
}

export { NewDesign, PrintCheck, AboutModal, ModeChanage };

const Modal = styled.div`
  position: fixed;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  background-color: rgb(0, 0, 0, 0.3);
  display: flex;
  align-items: center;
  justify-content: center;
`;

const ModalContent = styled.div`
  width: ${(props) => (props.color ? "800px" : "500px")};
  padding: 10px;
  border-radius: 10px;
  background-color: ${(props) => (props.color ? "#303236" : "#4774d5")};
  color: #ffffff;
`;

const ModalHeader = styled.div`
  padding: 2px;
  text-align: center;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const ModalBody = styled.div`
  padding: 10px;
  text-align: center;
`;

const ModalFooter = styled.div`
  padding: 10px;
  text-align: center;
`;

const Button = styled.button`
  float: right;
  width: 100px;
  height: 30px;
  margin: 5px;
  border-radius: 5px;
  border: none;
  background-color: light-grey;
`;
