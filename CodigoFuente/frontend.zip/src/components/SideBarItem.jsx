import React, { useState } from "react";
import styled from "styled-components";
import { MyContext } from "../globalContext";
import ColorBtn from "./ColorBtn";

const colors = [
  "#f24822",
  "#ffa629",
  "#ffcd29",
  "#14ae5c",
  "#00a2c2",
  "#0d99ff",
  "#9747ff",
  "#ff24bd",
];

const onDragStart = (event, nodeInfo) => {
  if (nodeInfo.type !== "Line") {
    event.dataTransfer.setData(
      "application/reactflow",
      JSON.stringify(nodeInfo)
    );
    event.dataTransfer.effectAllowed = "move";
  }
};

const SideBarItems = (props) => {
  const [showColor, setShowColor] = useState(false);
  const [selectItem, setSelectItem] = useState([]);
  const [edgeColor, setedgeColor] = React.useContext(MyContext);

  const onClick = (color) => {
    setedgeColor(color);
    setSelectItem(
      colors.map((item) => {
        if (item === color) {
          return true;
        } else {
          return false;
        }
      })
    );
  };
  return (
    <>
      {props.nodeInfo.type === "Line" ? (
        <Item>
          <img
            alt="tool"
            src={props.nodeInfo.img}
            width="100%"
            height="100%"
            onClick={() => setShowColor(!showColor)}
          />
          {showColor ? (
            <div
              style={{
                position: "absolute",
                top: "2px",
                right: "-300px",
                backgroundColor: "lightgrey",
                padding: "3px",
                borderRadius: "3px",
                display: "flex",
                zIndex: "6"
              }}
            >
              {colors.map((color, index) => (
                <ColorBtn
                  key={index}
                  color={color}
                  setColor={onClick}
                  selected={selectItem[index]}
                />
              ))}
            </div>
          ) : (
            ""
          )}
        </Item>
      ) : (
        <Item
          onClick={() => props.func(props.nodeInfo.num)}
          onDragStart={(event) => onDragStart(event, props.nodeInfo)}
          draggable
        >
          <img alt="tool" src={props.nodeInfo.img} width="100%" height="100%" />
        </Item>
      )}
    </>
  );
};
export default SideBarItems;

const Item = styled.div`
  width: 50px;
  height: 45px;
  margin: 5px 25px 5px 34px;
  position: relative;
  cursor: pointer;
`;
