import React from "react";
import styled from "styled-components";

const Text = (props) => {
  return (<Heading>{props.text}</Heading>);
};

export default Text;

const Heading = styled.h6`
  width: 15px;
  height: 15px;
  margin: 2px;
  border-radius: 50%;
  border: ${(props) => (props.selected ? "1px solid black" : "1px solid grey")};
  background: ${(props) => props.color};  
`;
