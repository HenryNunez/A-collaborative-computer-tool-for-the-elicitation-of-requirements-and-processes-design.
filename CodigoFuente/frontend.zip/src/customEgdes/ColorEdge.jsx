import React from 'react';
import { getBezierPath } from 'reactflow';


export default function CustomEdge({
  id,
  sourceX,
  sourceY,  
  targetX,
  targetY,
  sourcePosition,
  targetPosition,
  markerEnd,
  data,
}) {
  const [edgePath] = getBezierPath({
    sourceX,
    sourceY,
    sourcePosition,
    targetX,
    targetY,
    targetPosition,
  });

// console.log(markerEnd);
  return (
      <path
        id={id}
        className="react-flow__edge-path"
        style={{stroke: data.color, strokeWidth: '3', strokeDasharray: '0', strokeLinecap: 'butt'}}
        d={edgePath}
        markerEnd={markerEnd}              
      />
  );
}