import React, { useState } from "react";
import styled from "styled-components";
import { useReactFlow, useStoreApi } from "reactflow";
import "@reactflow/node-resizer/dist/style.css";
import ColorBtn from "../components/ColorBtn";

const colors = [
  "#f24822",
  "#ffa629",
  "#ffcd29",
  "#14ae5c",
  "#00a2c2",
  "#0d99ff",
  "#9747ff",
  "#ff24bd",
];

const CircleNode = ({ data, selected, id }) => {
  const { setNodes } = useReactFlow();
  const [showColor, setShowColor] = useState(false);
  const [selectItem, setSelectItem] = useState([]);
  const store = useStoreApi();

  const onChange = (evt) => {
    const { nodeInternals } = store.getState();
    setNodes(
      Array.from(nodeInternals.values()).map((node) => {
        if (node.id === id) {
          node.data = {
            ...node.data,
            label: evt.target.value,
          };
        }
        return node;
      })
    );
  };

  const onClick = (color) => {
    setSelectItem(
      colors.map((item) => {
        if (item === color) {
          return true;
        } else {
          return false;
        }
      })
    );
    const { nodeInternals } = store.getState();
    setNodes(
      Array.from(nodeInternals.values()).map((node) => {
        if (node.id === id) {
          node.style = {
            ...node.style,
            background: color,
          };
        }
        return node;
      })
    );
  };

  return (
    <div style={{ display: "flex", position: "relative" }}>
      <InputText onChange={onChange} />
      <span
        style={{ position: "absolute", right: "-20px", cursor: "pointer" }}
        onClick={() => setShowColor(!showColor)}
      >
        <svg viewBox="0 0 20 20" width="20px">
          <path d="M7 2a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 2zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 8zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 14zm6-8a2 2 0 1 0-.001-4.001A2 2 0 0 0 13 6zm0 2a2 2 0 1 0 .001 4.001A2 2 0 0 0 13 8zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 13 14z"></path>
        </svg>
      </span>
      {showColor ? (
        <div
          style={{
            position: "absolute",
            top: "-5px",
            right: "-320px",
            backgroundColor: "lightgrey",
            padding: "3px",
            borderRadius: "3px",
            display: "flex",
          }}
        >
          {colors.map((color, index) => (
            <ColorBtn
              key={index}
              color={color}
              setColor={onClick}
              selected={selectItem[index]}
            />
          ))}
        </div>
      ) : (
        ""
      )}
    </div>
  );
};
export default CircleNode;

const InputText = styled.textarea`
  text-align: center;
  padding-top: 2px;
  overflow: "hidden";
  resize: none;
  width: 100%;
  height: 100%;
  background: transparent;
  border: none;
  outline: "none";
`;
