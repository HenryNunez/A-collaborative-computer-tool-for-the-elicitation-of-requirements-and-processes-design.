import React from "react";
import styled from "styled-components";
import { NodeResizer } from "@reactflow/node-resizer";
import { useReactFlow, useStoreApi, useStore } from "reactflow";
import "@reactflow/node-resizer/dist/style.css";

const ClockNode = ({ data, selected, id }) => {
  const { setNodes } = useReactFlow();
  const store = useStoreApi();
  const label = useStore((s) => {
    const node = s.nodeInternals.get(id);
    return node.data.label;
  });
  const onChange = (evt) => {
    const { nodeInternals } = store.getState();
    setNodes(
      Array.from(nodeInternals.values()).map((node) => {
        if (node.id === id) {
          node.data = {
            ...node.data,
            label: evt.target.value,
          };
        }
        return node;
      })
    );
  };
  return (
    <>
      <Wrapper>
        <img alt="tool1" width={"30%"} height={"100%"} src={data.img} />
        <InputText
          defaultValue={label}
          onChange={onChange}
          selected={selected}
        />
      </Wrapper>
      <NodeResizer
        color="#1d9e30"
        isVisible={selected}
        minWidth={133}
        minHeight={35}
      />
    </>
  );
};
export default ClockNode;

const Wrapper = styled.div`
  width: 100%;
  height: 100%;
  display: flex;
`;

const InputText = styled.textarea`
  align-self: center;
  padding-top: 8px;    
  resize: none;
  width: 70%;
  height: 100%;
  background: transparent;
  border: transparent 1px solid;
  outline: ${(props) => (props.selected ? "" : "none")};
`;
