import React from "react";
import styled from "styled-components";

const LoopNode = ({ data, selected, id }) => {
  return (
    <Wrapper>
      <img alt="tool1" width={"30%"} height={"100%"} src={data.img} />
    </Wrapper>
  );
};
export default LoopNode;

const Wrapper = styled.div`
  width: 100%;
  height: 100%;
  display: flex;
`;
