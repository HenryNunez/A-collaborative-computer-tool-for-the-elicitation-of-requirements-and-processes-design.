import React, { useState } from "react";
import styled from "styled-components";
import { Handle } from "reactflow";
import { NodeResizer } from "@reactflow/node-resizer";
import { useReactFlow, useStoreApi, useStore } from "reactflow";
import "@reactflow/node-resizer/dist/style.css";
import ColorBtn from "../components/ColorBtn";

const colors = [
  "#f24822",
  "#ffa629",
  "#ffcd29",
  "#14ae5c",
  "#00a2c2",
  "#0d99ff",
  "#9747ff",
  "#ff24bd",
];

const PostNode = ({ data, selected, id }) => {
  const [showColor, setShowColor] = useState(false);
  const [selectItem, setSelectItem] = useState([]);  
  const { setNodes } = useReactFlow();
  const store = useStoreApi();
  const label = useStore((s) => {
    const node = s.nodeInternals.get(id);
    return node.data.label;
  });

  const label1 = useStore((s) => {
    const node = s.nodeInternals.get(id);
    return node.data.label1;
  });

  const userImg = useStore((s) => {
    const node = s.nodeInternals.get(id);
    return node.data.userAvatar;
  });

  const userName = useStore((s) => {
    const node = s.nodeInternals.get(id);
    return node.data.username;
  });

  const onChange = (evt) => {
    const { nodeInternals } = store.getState();
    setNodes(
      Array.from(nodeInternals.values()).map((node) => {
        if (node.id === id) {
          node.data = {
            ...node.data,
            label: evt.target.value,
          };
        }
        return node;
      })
    );
  };

  const onChange1 = (evt) => {
    const { nodeInternals } = store.getState();
    setNodes(
      Array.from(nodeInternals.values()).map((node) => {
        if (node.id === id) {
          node.data = {
            ...node.data,
            label1: evt.target.value,
          };
        }
        return node;
      })
    );
  };

  const onClick = (color) => {
    setSelectItem(colors.map((item) => {
      if(item === color){
        return true;
      }else{
        return false;
      }
    }));
    const { nodeInternals } = store.getState();
    setNodes(
      Array.from(nodeInternals.values()).map((node) => {
        if (node.id === id) {
          node.style = {
            ...node.style,
            background: color,
          };
        }
        return node;
      })
    );
  };

  return (
    <>
      <Wrapper>
        <Avata>
          <img alt="avata" src={`${userImg}`} width="100%" height="100%" />
        </Avata>
        <Text>{userName}</Text>
        <span
          style={{ position: "absolute", right: "10px", cursor: "pointer" }}
          onClick={() => setShowColor(!showColor)}
        >
          <svg viewBox="0 0 20 20" width="30px">
            <path d="M7 2a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 2zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 8zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 7 14zm6-8a2 2 0 1 0-.001-4.001A2 2 0 0 0 13 6zm0 2a2 2 0 1 0 .001 4.001A2 2 0 0 0 13 8zm0 6a2 2 0 1 0 .001 4.001A2 2 0 0 0 13 14z"></path>
          </svg>
        </span>
        {showColor ? (
          <div
            style={{
              position: "absolute",
              top: "3px",
              right: "-55px",
              backgroundColor: "lightgrey",
              padding: "3px",
              borderRadius: "3px",
            }}
          >
            {colors.map((color, index) => (
              <ColorBtn key={index} color={color} setColor={onClick} selected={selectItem[index]} />
            ))}
          </div>
        ) : (
          ""
        )}

        <ColorBtn />
      </Wrapper>
      <Input defaultValue={label1} onChange={onChange1} />
      <InputText defaultValue={label} onChange={onChange} selected={selected} />
      <NodeResizer
        color="#1d9e30"
        isVisible={selected}
        minWidth={350}
        minHeight={300}
      />
      <Handle
        type="source"
        position="right"
        id="a"
        style={{
          height: "20px",
          width: "20px",
          right: "-15px",
          cursor: "crosshair",
        }}
        isConnectable={true}
      />
      <Handle
        type="target"
        position="left"
        id="b"
        style={{
          height: "20px",
          width: "20px",
          left: "-15px",
          cursor: "crosshair",
        }}
        isConnectable={true}
      />
    </>
  );
};
export default PostNode;

const InputText = styled.textarea`
  align-self: center;
  resize: none;
  width: 100%;
  height: 75%;
  background: transparent;
  outline: ${(props) => (props.selected ? "" : "none")};
  font-size: 20px;
`;
const Input = styled.input`
  align-self: center;
  width: 100%;
  height: 10%;
  background: transparent;
  outline: ${(props) => (props.selected ? "" : "none")};
  font-size: 20px;
`;
const Wrapper = styled.div`
  width: 100%;
  height: 15%;
  display: flex;
  flex-direction: row;
  align-items: center;
  position: relative;
`;

const Avata = styled.div`
  float: left;
  margin: 3px;
  width: 10%;
  border-radius: 50%;
`;

const Text = styled.h6`
  float: left;
  text-align: center;
  font-size: 30px;
`;
