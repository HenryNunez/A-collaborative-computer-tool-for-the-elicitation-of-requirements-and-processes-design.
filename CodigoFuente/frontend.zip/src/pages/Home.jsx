import React from "react";
import styled from "styled-components";
import { ReactFlowProvider } from "reactflow";
import "reactflow/dist/style.css";

import SideBar from "../Layouts/SideBar";
import WorkPlace from "../Layouts/WorkPlace";
import Footer from "../Layouts/Footer";

function Home(props) {
  return (
    <ReactFlowProvider>
      <Grid1>
        <Grid grid={1.3}>
          <SideBar mode={props.mode} />
        </Grid>
        <Grid grid={10.7}>
          <WorkPlace newDesign={props.newDesign} userInfo={props.userInfo} />
          <Footer onClick={props.onClickBtn} />
        </Grid>
      </Grid1>
    </ReactFlowProvider>
  );
}

export default Home;

const Grid = styled.div`
  width: ${(props) => 8.333333333333333 * props.grid + "%"};
  display: flex;
  flex-direction: column;
  justify-content: center;
  flex-direction: center;
`;

const Grid1 = styled.div`
  width: 100%;
  display: felx;
`;
