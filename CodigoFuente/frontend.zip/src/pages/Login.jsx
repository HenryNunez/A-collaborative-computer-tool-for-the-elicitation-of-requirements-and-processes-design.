import React, { useState } from "react";
import styled from "styled-components";
import { Link } from "react-router-dom";
import api from "../api";
import { GoogleLogin } from "@react-oauth/google";
import { GoogleOAuthProvider } from "@react-oauth/google";
import { url } from "../constant";
import { AboutModal } from "../components/Modal";

const clientId = process.env.REACT_APP_GOOGLE_CLIENT_ID;

const Login = () => {
  const [error, setError] = useState("");
  const [show, setShow] = useState(false);
  const apiRequest = async (credential) => {
    api(`${url}/api/users/login`, credential, "POST").then((res) => {
      console.log(res, "dddd");
      setError(res);
    });
  };
  const img = "assets/images/background.png";
  return (
    <>
      <Container img={img}>
        <Wrapper color={"#47C4D5"}>
          <header
            style={{
              textAlign: "center",
              height: "10%",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              marginTop: "35px",
            }}
          >
            <h2 style={{ margin: "0px" }}>BIENVENIDO</h2>
          </header>

          <main
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              height: "70%",
              margin: "0px",
            }}
          >
            <img
              alt="avata"
              src={"assets/images/logo1.png"}
              width="120px"
              height="160px"
            />
            <h1 style={{ margin: "0px" }}>isEASY</h1>
            <h1 style={{ margin: "0px" }}>Modeler</h1>
          </main>

          <footer style={{ height: "10%" }}>
            <nav
              style={{
                display: "flex",
                justifyContent: "center",
                cursor: "pointer",
              }}
              onClick={() => setShow(true)}
            >
              <span
                style={{ color: "white", fontSize: "20px", fontWeight: "bold" }}
              >
                About us
              </span>
            </nav>
          </footer>
        </Wrapper>
        <Wrapper color={"#4774D5"}>
          <header
            style={{
              textAlign: "center",
              height: "25%",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <h1 style={{ color: "white" }}>Log in</h1>
          </header>

          <main
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              height: "45%",
              marginTop: "20px",
            }}
          >
            <GoogleOAuthProvider clientId={clientId}>
              <>
                {error && <p style={{ color: "red" }}>{error}</p>}
                {/* {loading ? <div>Loading....</div> : <div id="loginDiv"></div>} */}
                <GoogleLogin
                  onSuccess={(credentialResponse) => {
                    apiRequest(credentialResponse?.credential);
                  }}
                  onError={() => {
                    console.log("Login Failed");
                  }}
                />
              </>
            </GoogleOAuthProvider>
          </main>

          <footer style={{ height: "25%" }}>
            <nav style={{ display: "flex", justifyContent: "center" }}>
              <span
                style={{ color: "white", fontSize: "20px", fontWeight: "bold" }}
              >
                Not a member?&nbsp;&nbsp;&nbsp;
              </span>
              <Link
                to="/signup"
                style={{ color: "white", fontSize: "20px", fontWeight: "bold" }}
              >
                Sign Up
              </Link>
            </nav>
          </footer>
        </Wrapper>
      </Container>
      <AboutModal show={show} onHide={() => setShow(false)} about={true} />
    </>
  );
};

export default Login;

const Container = styled.div`
  height: 100vh;
  background-image: url(${(props) => props.img});
  background-repeat: repeat;
  display: flex;
  justify-content: center;
  align-items: center;
`;

const Wrapper = styled.div`
  width: 300px;
  height: 70vh;
  background-color: ${(props) => props.color};
  border-radius: 10px;
  margin: 0px;
`;
